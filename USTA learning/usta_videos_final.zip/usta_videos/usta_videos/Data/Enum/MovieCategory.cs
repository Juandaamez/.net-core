﻿namespace usta_videos.Data.Enum
{
    public enum MovieCategory
    {
        Action = 1,
        Comedy,
        Drama,
        Documentary,
        Horror,
        Anime,
        Cartoon,
        Adventure,
        Kids,
        Love
    }
}
